﻿namespace Proyecto2;
    public class CuentaBancaria
    {
        public string TipoCuenta { get; set; }
        public string Nombre { get; set; }
        public string DPI { get; set; }
        public string Direccion { get; set; }
        public string Telefono { get; set; }
        public decimal Saldo { get; set; }
        public List<Transaccion> Transacciones { get; set; }

        public CuentaBancaria(string tipoCuenta, string nombre, string dpi, string direccion, string telefono)
        {
            TipoCuenta = tipoCuenta;
            Nombre = nombre;
            DPI = dpi;
            Direccion = direccion;
            Telefono = telefono;
            Saldo = 2500.00M;
            Transacciones = new List<Transaccion>();
        }

        public void MostrarInformacion()
        {
            Console.WriteLine($"Tipo de Cuenta: {TipoCuenta}");
            Console.WriteLine($"Nombre: {Nombre}");
            Console.WriteLine($"DPI: {DPI}");
            Console.WriteLine($"Dirección: {Direccion}");
            Console.WriteLine($"Teléfono: {Telefono}");
            Console.WriteLine($"Saldo: Q{Saldo}");
        }

        public void ComprarProductoFinanciero()
        {
            decimal monto = Saldo * 0.10M;
            Saldo -= monto;
            RegistrarTransaccion(monto, "Debito");
            Console.WriteLine($"Nuevo saldo después de comprar producto financiero: Q{Saldo}");
        }

        public void VenderProductoFinanciero()
        {
            if (Saldo > 500.00M)
            {
                decimal monto = Saldo * 0.11M;
                Saldo += monto;
                RegistrarTransaccion(monto, "Credito");
                Console.WriteLine($"Nuevo saldo después de vender producto financiero: Q{Saldo}");
            }
            else
            {
                Console.WriteLine("Saldo insuficiente para realizar esta transacción.");
            }
        }

        public void AbonarCuenta()
        {
            if (Saldo > 500.00M)
            {
                Saldo *= 2;
                RegistrarTransaccion(Saldo, "Credito");
                Console.WriteLine($"Nuevo saldo después de abonar a la cuenta: Q{Saldo}");
            }
            else
            {
                Console.WriteLine("Saldo insuficiente para realizar esta transacción.");
            }
        }

        public void SimularPasoDelTiempo(int meses, bool capitalizacionMensual)
        {
            decimal tasaInteres = 0.02M;
            decimal incremento = Saldo * tasaInteres * meses;
            if (!capitalizacionMensual) incremento /= 2;
            Saldo += incremento;
            RegistrarTransaccion(incremento, "Credito");
            Console.WriteLine($"Saldo después de simular el paso del tiempo: Q{Saldo}");
        }

        private void RegistrarTransaccion(decimal monto, string tipo)
        {
            Transacciones.Add(new Transaccion(DateTime.Now, monto, tipo));
        }

        public void MostrarTransacciones()
        {
            Console.WriteLine("Historial de transacciones:");
            foreach (var transaccion in Transacciones)
            {
                Console.WriteLine(transaccion);
            }
        }
    }
