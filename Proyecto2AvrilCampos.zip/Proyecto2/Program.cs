﻿namespace Proyecto2;
public class Program
{
    static void Main()
    {
        Console.WriteLine("Bienvenido al sistema bancario");
        var cuenta = CrearCuenta();

        bool contnue = true;
        while (contnue)
        {
            MostrarMenu();
            int opcion = int.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    cuenta.MostrarInformacion();
                    break;
                case 2:
                    cuenta.ComprarProductoFinanciero();
                    break;
                case 3:
                    cuenta.VenderProductoFinanciero();
                    break;
                case 4:
                    cuenta.AbonarCuenta();
                    break;
                case 5:
                    SimularTiempo(cuenta);
                    break;
                case 6:
                    cuenta.MostrarTransacciones();
                    break;
                case 7:
                    contnue = false;
                    break;
                default:
                    Console.WriteLine("Opción no válida. Intente de nuevo.");
                    break;
            }

            if (contnue)
            {
                Console.WriteLine("¿Desea realizar otra operación? (s/n)");
                contnue = Console.ReadLine().ToLower() == "s";
            }
        }
        Console.WriteLine("Gracias por usar el sistema bancario.");
    }

    static void MostrarMenu()
    {
        Console.WriteLine("---------- MENU ----------");
        Console.WriteLine("Seleccione una opción:");
        Console.WriteLine("1. Ver información de la cuenta");
        Console.WriteLine("2. Comprar producto financiero");
        Console.WriteLine("3. Vender producto financiero");
        Console.WriteLine("4. Abonar a la cuenta");
        Console.WriteLine("5. Simular paso del tiempo");
        Console.WriteLine("6. Ver transacciones");
        Console.WriteLine("7. Salir");
        Console.WriteLine("----------------------------");
    }

    static CuentaBancaria CrearCuenta()
    {
        Console.WriteLine("Ingrese el tipo de cuenta: 1.) Monetaria quetzales, 2.) Monetaria dólares, 3.) Ahorro quetzales, 4.) Ahorro dólares");
        Console.WriteLine("Escriba su opcion:");
        string tipoCuenta = Console.ReadLine();
        Console.WriteLine("Presione una tecla para continuar...");
        Console.ReadKey();
        Console.Clear();
        
        Console.WriteLine("Ingrese su nombre:");
        string nombre = Console.ReadLine();
        Console.WriteLine("Presione una tecla para continuar...");
        Console.ReadKey();
        Console.Clear();

        Console.WriteLine("Ingrese su DPI (5 caracteres numéricos):");
        string dpi = Console.ReadLine();
        Console.WriteLine("Presione una tecla para continuar...");
        Console.ReadKey();
        Console.Clear();
        while (dpi.Length != 5)
        {
            Console.WriteLine("DPI inválido. Ingrese un DPI de 5 caracteres numéricos:");
            dpi = Console.ReadLine();
            Console.WriteLine("Presione una tecla para continuar...");
            Console.ReadKey();
            Console.Clear();
        }
        
        Console.WriteLine("Ingrese su dirección:");
        string direccion = Console.ReadLine();
        Console.WriteLine("Presione una tecla para continuar...");
        Console.ReadKey();
        Console.Clear();
        
        Console.WriteLine("Ingrese su teléfono:");
        string telefono = Console.ReadLine();
        Console.WriteLine("Presione una tecla para continuar...");
        Console.ReadKey();
        Console.Clear();

        return new CuentaBancaria(tipoCuenta, nombre, dpi, direccion, telefono);
    }

    static void SimularTiempo(CuentaBancaria cuenta)
    {
        Console.WriteLine("Ingrese la cantidad de meses a simular:");
        int meses = int.Parse(Console.ReadLine());
        Console.WriteLine("¿Capitalización mensual? (s/n):");
        bool capitalizacionMensual = Console.ReadLine().ToLower() == "s";
        cuenta.SimularPasoDelTiempo(meses, capitalizacionMensual);
    }
}
