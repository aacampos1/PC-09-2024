﻿namespace Proyecto2;

public class Transaccion
{
    public DateTime Fecha { get; set; }
    public decimal Monto { get; set; }
    public string Tipo { get; set; }

    public Transaccion(DateTime fecha, decimal monto, string tipo)
    {
        Fecha = fecha;
        Monto = monto;
        Tipo = tipo;
    }

    public override string ToString()
    {
        return $"{Fecha}: {Tipo} de Q{Monto}";
    }
}